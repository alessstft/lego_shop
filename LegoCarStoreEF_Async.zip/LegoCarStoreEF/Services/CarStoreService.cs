using LegoCarStoreEF.Models;
using LegoCarStoreEF.Data;

namespace LegoCarStoreEF.Services
{
    public class CarStoreService
    {
        private readonly LegoCarContext _context;

        public CarStoreService(LegoCarContext context)
        {
            _context = context;
        }

        public void AddCar(string name, decimal price)
        {
            _context.Cars.Add(new LegoCar { Name = name, Price = price });
            _context.SaveChanges();
        }

        public List<LegoCar> GetAllCars() => _context.Cars.ToList();

        public bool RemoveCar(int id)
        {
            var car = _context.Cars.FirstOrDefault(c => c.Id == id);
            if (car == null) return false;
            _context.Cars.Remove(car);
            _context.SaveChanges();
            return true;
        }
    }
}